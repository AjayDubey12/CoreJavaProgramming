package abstractKeyword;

public class A extends AbstractTest implements B{

	public static void main(String[] args) {
		A a=new A();
		a.m2();
		a.m3();
	}

@Override
public void m2() {
	System.out.println("overriden Abstract method");
	
}

@Override
public void m3() {
	System.out.println("interface inheritated method");
	
}


}
