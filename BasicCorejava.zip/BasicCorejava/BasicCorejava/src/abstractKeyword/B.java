package abstractKeyword;

public interface B {
void m3();
}
