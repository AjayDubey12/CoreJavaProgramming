package abstractKeyword;

public  abstract  class AbstractTest {
	private static int i;

	public final void m1() {

		System.out.println("m1 method");
	}

	public AbstractTest() {// we can define constructor inside abstract class
							// but we can not have inside interface

	}
 abstract void  m2();

	AbstractTest(int i) {
		this.i = i;
	}
}
