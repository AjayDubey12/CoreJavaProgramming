package overridePack;

import java.io.IOException;

public class A {
public void m()throws Exception
{
	
	System.out.println("superclass");
	
}
}
