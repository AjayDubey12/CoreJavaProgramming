package overridePack;

import java.io.IOException;

public class B extends A {
public void m(){
	
	System.out.println("Child");
	
	
}
	public static void main(String[] args) {
		A a=new B();
try {
	a.m();
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
