package testPractice;

public class SringTest {
	 public void foo(String s) {
		 System.out.println("String");
		 }

		 public void foo(StringBuffer sb){
		 System.out.println("StringBuffer");
		 }

	public static void main(String[] args) {
	String s="AABBCCDDAA";
	int len=s.length();
	String sub1=s.substring(0, 2);
	String sub2=s.substring(s.length()-2);
	sub2=sub2.toLowerCase();
	//check first two character and last Two character are equal
	System.out.println(sub1.equalsIgnoreCase(sub2));
	System.out.println(sub1==sub2);
	
	
	/*String s1 = new String("pankaj");
	String s2 = new String("PANKAJ");
	System.out.println(s1 =s2);
	
	new SringTest().foo(null);*/
	System.out.println("use of intern() method in string comparision##############");
	String s1 = "Test";
    String s2 = "Test";
    String s3 = new String("Test");
    final String s4 = s3.intern();//create string object into string pool and return string object reference from pool.
    System.out.println(s1 == s2);
    System.out.println(s2 == s3);
    System.out.println(s3 == s4);
    System.out.println(s1 == s3);
    System.out.println(s1 == s4);
    System.out.println(s1.equals(s2));
    System.out.println(s2.equals(s3));
    System.out.println(s3.equals(s4));
    System.out.println(s1.equals(s4));
    System.out.println(s1.equals(s3));
    
    System.out.println("#####");
    int n=s1.length();
 System.out.println("##########"+s1.substring(s1.length())); // print empty String ,will not throw exception
 System.out.println("##########"+s1.substring(1,1));// print empty String
 System.out.println("##########"+s1.substring(-1,3));//throw StringIndexOutOfBoundException
 System.out.println("##########"+s1.substring(2,1));//throw StringIndexOutOfBoundException
 System.out.println("##########"+s1.substring(5,s1.length()));//throw StringIndexOutOfBoundException
	}

}
