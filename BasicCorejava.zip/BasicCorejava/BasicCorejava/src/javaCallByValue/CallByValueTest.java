package javaCallByValue;

public class CallByValueTest {
	public static void swapByValue(int a, int b) {
		int temp = a;
		a = b;
		b = temp;

	}
	public static void tricky(Point arg1, Point arg2)
	{
	  arg1.x = 100;
	  arg1.y = 100;
	  Point temp = arg1;
	  arg1 = arg2;
	  arg2 = temp;
	}
	public static void main(String[] args) {
		Point p1 = new Point(0, 0);
		Point p2 = new Point(1, 1);
		System.out.println("Point P1 parameter"+"   "+p1.getX()+"   "+p1.getY());
		swapByValue(p1.getX(),p1.getY());
		
		
		
		tricky(p1,p2);
		System.out.println("after swaping");
		System.out.println("Point P1 parameter"+"   "+p1.getX()+"   "+p1.getY());
		System.out.println("Point P2 parameter"+"   "+p2.getX()+"   "+p2.getY());//since original object references not changed 
		                                                                        //This means the references passed to the method are actually copies of the original references.
	//if want to swap value then made changes in original object as:
		Point temp=p1;
		p1=p2;
		p2=temp;
		System.out.println("Point P1 parameter"+"   "+p1.getX()+"   "+p1.getY());
		System.out.println("Point P2 parameter"+"   "+p2.getX()+"   "+p2.getY());
		
		//By  David Flanagan
		//Java manipulates objects 'by reference,' but it passes object references to methods 'by value.'"
		//As a result, you cannot write a standard swap method to swap objects.
	}

}
