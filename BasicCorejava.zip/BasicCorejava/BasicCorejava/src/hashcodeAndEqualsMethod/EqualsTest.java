package hashcodeAndEqualsMethod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class EqualsTest {
    public static void main(String[] args) {
    	  Employee e1 = new Employee(100);
          Employee e2 = new Employee(100);
   
        Employee e3 = new Employee(100,"Ajay","dubey","IT");
        Employee e4 = new Employee(100,"jay","dubey","IT");
 
/*        e1.setId(100);
        e2.setId(100);
*/ 
        //Prints false in console
        //System.out.println(e1.equals(e2));
        HashMap<Employee,String>map=new HashMap<Employee,String>();
        map.put(e1,"1");
        map.put(e2,"2");
        System.out.println(map.size());
        
        
        System.out.println(map.get(e2));
        System.out.println("Hash code check"+" "+e1.hashCode()+"   "+e2.hashCode());
        System.out.println("equality check"+"   "+e1.equals(e2));
        
        HashSet<Employee> s=new HashSet<Employee>();
        s.add(e1);
        s.add(e2);
        System.out.println(s);
        System.out.println(s.contains(new Employee(100)));
    }
}