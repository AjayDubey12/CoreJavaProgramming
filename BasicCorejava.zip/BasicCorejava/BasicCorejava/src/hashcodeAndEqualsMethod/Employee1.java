package hashcodeAndEqualsMethod;
class Employee1
	{
	    private Integer id;
	    private String firstname;
	    private String lastName;
	    private String department;
	 
	   public Employee1(int i) {
			id=i;// TODO Auto-generated constructor stub
		}
	    
		public Employee1(Integer id, String firstname, String lastName, String department) {
			super();
			this.id = id;
			this.firstname = firstname;
			this.lastName = lastName;
			this.department = department;
		}

		public Integer getId() {
	        return id;
	    }
	    public void setId(Integer id) {
	        this.id = id;
	    }
	    public String getFirstname() {
	        return firstname;
	    }
	    public void setFirstname(String firstname) {
	        this.firstname = firstname;
	    }
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    public String getDepartment() {
	        return department;
	    }
	    public void setDepartment(String department) {
	        this.department = department;
	    }

		@Override
		public String toString() {
			return "Employee1 [id=" + id + ", firstname=" + firstname + ", lastName=" + lastName + ", department="
					+ department + "]";
		}
	   
	    
	    }