package hashcodeAndEqualsMethod;

import java.util.HashMap;
import java.util.HashSet;

public class WithoutoverrideHashcode {
    
		
	public static void main(String[] args) {
		

		Employee1 e1 = new Employee1(100);
        Employee1 e2 = new Employee1(100);
 
      Employee1 e3 = new Employee1(100,"Ajay","dubey","IT");
      Employee1 e4 = new Employee1(100,"jay","dubey","IT");

/*        e1.setId(100);
      e2.setId(100);
*/ 
      //Prints false in console
      //System.out.println(e1.equals(e2));
      HashMap<Employee1,String>map=new HashMap<Employee1,String>();
      map.put(e1,"1");
      map.put(e2,"2");
      System.out.println(map.size());
      
      
      System.out.println(map.get(e2));
      System.out.println("Hash code check"+" "+e1.hashCode()+"   "+e2.hashCode());
      System.out.println("equality check"+"   "+e1.equals(e2));
      
      HashSet<Employee1> s=new HashSet<Employee1>();
      s.add(e1);
      s.add(e2);
      System.out.println(s);
      System.out.println(s.contains(new Employee1(100)));
  }
}


