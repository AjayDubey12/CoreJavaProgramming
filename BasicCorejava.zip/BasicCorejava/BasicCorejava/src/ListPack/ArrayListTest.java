package ListPack;

import java.util.ArrayList;

public class ArrayListTest {
	
	
	public static void main(String args[]){
ArrayList al=new ArrayList();


al.add("a");
al.add("a");
al.add("a");
al.add(null);
al.remove(3);

System.out.println(al);

}}
