package ListPack;

public class LinkedListTest {

}
