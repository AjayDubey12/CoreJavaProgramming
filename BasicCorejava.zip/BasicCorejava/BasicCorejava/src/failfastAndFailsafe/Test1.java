package failfastAndFailsafe;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Test1 {

	public static void main(String[] args) {
		ConcurrentHashMap<String,String>map=new ConcurrentHashMap<String,String>();
		map.put("1", "first");
		map.put("2", "second");
		map.put("3", "third");
		map.put("4", "forth");
	Set<Entry<String,String>>entry=	map.entrySet();
	Iterator<Entry<String, String>> i=entry.iterator();
	while(i.hasNext()){}
	Entry e1=i.next();
	System.out.println(e1.getKey());
	
	map.remove(2);
	}

}
