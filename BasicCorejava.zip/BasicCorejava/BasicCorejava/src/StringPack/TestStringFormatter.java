package StringPack;
public class TestStringFormatter {  
public static void main(String[] args) {  
    System.out.println(StringFormatter.reverseToggle("my name is khan"));  
    System.out.println(StringFormatter.reverseToggle("I am sonoo jaiswal"));      
    }  
}  