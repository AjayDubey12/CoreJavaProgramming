package StringPack;

import java.util.HashSet;
import java.util.Scanner;

public class UniquePalindromTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("enter string");
		String str = sc.nextLine();

		String[] words = str.split(" ");
		HashSet<String> set = new HashSet<String>();
		boolean isPalindrom=false;
		int count=0;
		for (String i : words) {
			set.add(i);

		}
		for(String s:set){
			
			char[]ch=s.toCharArray();
			for(int i=0;i<ch.length/2;i++){
				
				if(ch[i]==ch[ch.length-i-1]){
					isPalindrom=true;
				}
				else {isPalindrom=false;
				break;
				}
			}
			
			if(isPalindrom==true){
				System.out.println(s);
				count++;
			}
		}
		System.out.println("total unique palindrom"+"  "  +count);

	}

}
