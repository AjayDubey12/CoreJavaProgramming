package setPack;

import java.util.HashSet;

public class HashSetTest {

	public static void main(String[] args) {
		HashSet s=new HashSet();
			s.add("a");
			s.add("b");
		System.out.println(s.add("a"));
		System.out.println(s.contains("a"));
		System.out.println(s);
	}

}
