package serialisationAndDeserialisation;

import java.io.Serializable;

public class Employee implements Serializable {
private int empid;
private String empName;
private String Address;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public Employee(int empid, String empName, String address) {
	super();
	this.empid = empid;
	this.empName = empName;
	Address = address;
}


}
