package serialisationAndDeserialisation;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

/** Copyright (c), AnkitMittal JavaMadeSoEasy.com */
/*Author : AnkitMittal  Copyright- contents must not be reproduced in any form*/
class Employee1 implements Serializable {
	private static final long	serialVersionUID = -5035244089196574486L;
       //we haven�t declared SerialVersionUId  
    private Integer id;
    private String name;
    
//modify
    private String addedField;
    public Employee1(Integer id, String name) {
           this.id = id;
           this.name = name;
    }
 
    @Override
    public String toString() {
           return "Employee [id=" + id + ", name=" + name + "]";
    }
 
}
 
public class SerializeEmployee {
 
    public static void main(String[] args) {
 
           Employee1 object1 = new Employee1(1, "amy");
           Employee1 object2 = new Employee1(2, "ankit");
 
           try {
                  OutputStream fout = new FileOutputStream("ser.txt");
                  ObjectOutput oout = new ObjectOutputStream(fout);
                  System.out.println("Serialization process has started, serializing employee objects...");
                  oout.writeObject(object1);
                  oout.writeObject(object2);
			fout.close();
			oout.close();
                  System.out.println("Object Serialization completed.");
                  
           } catch (IOException ioe) {
                  ioe.printStackTrace();
           }
 
    }
 
}
/*OUTPUT
 
Serialization process has started, serializing employee objects...
Object Serialization completed.
 
*/

