package serialisationAndDeserialisation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class MainClass {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Employee e=new Employee(100, "ajay", "Bangalore");
		
		System.out.println("Serializing-writing state of employee objct into file  ");
		FileOutputStream fos=new FileOutputStream("abc.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(e);
		
		
		System.out.println("deserializing--reading object");
		
		FileInputStream fis=new FileInputStream("abc.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Employee e1=(Employee) ois.readObject();
		System.out.println(e1.getEmpid()+" "+e1.getEmpName()+""
				+ " "+e1.getAddress());

	}

}
