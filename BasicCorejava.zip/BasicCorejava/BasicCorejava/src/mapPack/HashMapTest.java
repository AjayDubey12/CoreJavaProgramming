package mapPack;

import java.util.HashMap;

public class HashMapTest {

	public static void main(String[] args) {
		Employee e=new Employee(101,"Ajay",26,"UP");
		//System.out.println(e);
		
		Employee e1=new Employee(102,"Ajay",27,"UP");
		Employee e2=new Employee(102,"adi",20,"UP");
		 /*custom object dublicate will be inserted 
         because hashcode() and equlals() not override.
         each key points different bucket location because of different objects*/
		/*HashMap hm1=new HashMap();                        
		hm1.put(e, "Employee0");
		hm1.put(e1, "Employee1");
		hm1.put(e2, "Employee3");
		hm1.put(e2, "Employee4");
		
		System.out.println(hm1);*/
		
		
		
		//after overriding () and equals() based on emp id.
//		both object point same hash value based on id because both object equals based on id. 
		HashMap hm=new HashMap();
		hm.put(null,"101");
		hm.put(null,"102");
		hm.put(e1,"emp1");
		hm.put(e1,"new");
		hm.put(e2, "emp2");  // e1 and e2 both point same employee object so dublicate value override with e2.
		System.out.println(hm);
		System.out.println(hm.size());
	System.out.println(e1.equals(e2));
		//System.out.println(e1.hashCode()+"     ///"+ e2.hashCode());
		
	}

}
