package mapPack;

public class Employee {
private int empId;
private String name;
private int age;
private String address;
public Employee(int id){
	this.empId=id;
}
public Employee(int id, String empName, int age, String addr) {
	empId=id;
	name=empName;
	this.age=age;
	address=addr;
	
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String toString() {
	return "Employee [empId=" + empId + ", name=" + name + ", age=" + age
			+ ", address=" + address + "]";
}
@Override
public int hashCode() {
	int hashValue=this.empId;
	return hashValue;
}
@Override
public boolean equals(Object obj) {
Employee e=	(Employee)obj;
	return (this.getEmpId()==e.getEmpId());

}
}
