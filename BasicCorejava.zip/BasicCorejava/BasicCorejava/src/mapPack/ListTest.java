package mapPack;

import java.util.HashSet;
import java.util.Set;

public class ListTest {

	public static void main(String[] args) {
	Set<Employee> list=	new HashSet<Employee>();
	list.add(new Employee(100));
	Set list1=list;
	list1.add(new Employee(200));
	System.out.println(list1.size()+" "+list.size());

	}

}
