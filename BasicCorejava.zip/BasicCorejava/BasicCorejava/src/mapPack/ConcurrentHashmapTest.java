package mapPack;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashmapTest {

	public static void main(String[] args) {
		ConcurrentHashMap chm=new ConcurrentHashMap();
		chm.put("1", "first");
		chm.put("null","second");
		chm.put("null","third");
		System.out.println(chm);
	}

}
