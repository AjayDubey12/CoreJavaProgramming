package mapPack;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashmapTest {

	public static void main(String[] args) {
		Employee e=new Employee(101,"Ajay",26,"UP");
		//System.out.println(e);
		
		Employee e1=new Employee(102,"adi",20,"UP");
		Employee e2=new Employee(102,"adi",20,"UP");
		LinkedHashMap hm=new LinkedHashMap();                        
		hm.put(e, "Employee0");
		hm.put(e1, "Employee1");
		hm.put(e2, "Employee3");
		System.out.println(hm);
		
		/*LinkedHashMap hm=new LinkedHashMap();
		hm.put(null,"101");
		hm.put(null,"102");
		System.out.println(hm);*/

	}

}
