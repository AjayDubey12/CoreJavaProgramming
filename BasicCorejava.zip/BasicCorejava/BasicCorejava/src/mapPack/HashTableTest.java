package mapPack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

public class HashTableTest {

	public static void main(String[] args) {
		Employee e=new Employee(101,"Ajay",26,"UP");
		//System.out.println(e);
		
		Employee e1=new Employee(102,"adi",20,"UP");
		Employee e2=new Employee(102,"adi",20,"UP");
		HashMap hm=new HashMap();                         /*custom object dublicate will be inserted 
		                                                 because hashcode() and equlals() not override.
		                                                  each key points different bucket location because of different objects*/
	
		System.out.println("size before"+hm.size());
		
		hm.put(e, "Employee0");
		
		hm.put(e1, "Employee1");
		hm.put(e2, "Employee3");
		hm.put(e2, "Employee4");
		System.out.println(hm);
		System.out.println("size after inserting "+hm.size());
		/*Hashtable hm=new Hashtable();
		hm.put(null,"101");// throw NullPointerException
		hm.put("Ajay",null);//// throw NullPointerException
		System.out.println(hm);*/
		
	}
	

}
