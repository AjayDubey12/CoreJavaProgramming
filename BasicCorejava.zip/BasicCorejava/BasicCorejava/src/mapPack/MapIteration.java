package mapPack;

import java.io.ObjectInputStream.GetField;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Map;

import java.util.Set;

public class MapIteration {

	public static void main(String[] args) {
		Employee e=new Employee(101,"Ajay",26,"UP");
	//	System.out.println(e);
		
		Employee e1=new Employee(102,"adi",20,"UP");
		Employee e2=new Employee(102,"adi",20,"UP");
		HashMap hm=new HashMap();                         
		hm.put(e, "Employee0");
		hm.put(e1, "Employee1");
		hm.put(e2, "Employee3");
		
		// using iterator of entryset()
		Set<Map.Entry<Employee,String>>entryset=hm.entrySet();
		Iterator<Entry<Employee,String>> itr=entryset.iterator();
		
		while(itr.hasNext()){
			Entry o=(Entry) itr.next();
		System.out.println("Key="+o.getKey()+" "+"value="+o.getValue());
		}
		/*//using for Each loop
		Set<Employee>s=hm.keySet();
	
	for(Employee key:s){
		
		
		System.out.println("key="+key +" "+"value="+hm.get(key));
		*/
		
	}
	}


