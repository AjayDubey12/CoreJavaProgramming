package threadPack;

public class ThreadSafeSingleton {
private static volatile ThreadSafeSingleton instance;
private ThreadSafeSingleton(){}
public static ThreadSafeSingleton getInstance(){
	if (instance==null){
		//first time it apply lock and read and write instance  singleton object.
		//second time will not apply lock because condition will false as we declare variable as volatile.
		//once create object for sigleton then all other thread able to see new instance immediately.
		synchronized(ThreadSafeSingleton.class){
			
			if (instance==null){
				
				instance=new ThreadSafeSingleton();
			}
			
			
		}
		
		
	}
	
	
	return instance;
}
}
