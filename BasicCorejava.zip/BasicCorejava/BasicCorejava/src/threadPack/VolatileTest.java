package threadPack;

public class VolatileTest {

	public static void main(String[] args) {
		A t1=new A();
		A t2=new A();
		t1.start();
		t2.start();

	}

}
