package threadPack;

public class TestTreadSafesingletonwithVolatileModifier {

	public static void main(String[] args) {
		ThreadSafeSingleton t=ThreadSafeSingleton.getInstance();
		System.out.println(t.hashCode());
Thread t1=new Thread(){
	
public void run(){
	
	
	ThreadSafeSingleton t=ThreadSafeSingleton.getInstance();
	System.out.println("thread1");
	System.out.println(t.hashCode());
}	
	
};

Thread t2=new Thread(){
	
public void run(){
	
	
	ThreadSafeSingleton t=ThreadSafeSingleton.getInstance();
	System.out.println("thread2");
	System.out.println(t.hashCode());
}	
	
};
t1.start();
t2.start();
	}

}
