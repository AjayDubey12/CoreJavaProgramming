package threadPack;

public class A extends Thread {
	public volatile  int i;
public synchronized void run(){
	System.out.println("thread started ");
	++i;
	System.out.println(i);
}
	
	
}

