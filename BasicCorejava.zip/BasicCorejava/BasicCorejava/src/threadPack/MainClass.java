package threadPack;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		A a=new A();
		a.start();
a.wait();
	}

}
