package finalKeyword;

public class B extends A{
	static final int j=10;
	final void m(){
		System.out.println("child  method");
	}
	public static void main(String[] args) {
	//	B.j=11; j isfinall can not reaasign value.
		System.out.println(j+1);
	}

}
