package finalKeyword;

public class A {
	public  A(){}
	private static final int i=10;
      void m(){
	System.out.println("final method");
	
	
      }
}
