package basicProgramingTest;

public class A {
private A(){
	System.out.println("private constructor");
	
	
	
}
//How can we create objects if we make the constructor private ?
//Ans:We can create new object through static method or static block
/*public static void main(String args[]){
	
	A a=new A();
}*/
}
