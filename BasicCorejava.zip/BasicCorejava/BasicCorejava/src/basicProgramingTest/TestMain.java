package basicProgramingTest;

public class TestMain {

	public static void main(String[] args) {
	//	A a=new A();//constructor not visible
		
		
		String str1 = new String("String1");
		String str2 = new String("String1");
		System.out.println(str1 == str2);
		System.out.println(str1.equals(str2));
		str1 = str2;
		System.out.println(str1 == str2);
		
		String str3 = "String1";
		String str4 = "String2";
		str1.concat("String3");
		
		System.out.println("############");
		System.out.println(str1);
		System.out.println(str3);
		System.out.print(str4);
	}

}
