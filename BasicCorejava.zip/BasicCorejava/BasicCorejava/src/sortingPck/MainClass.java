package sortingPck;

import java.util.ArrayList;

import java.util.Collections;

public class MainClass {

	public static void main(String[] args) {
		Employee e1=new Employee(24,"Ajay",50000);
		Employee e2=new Employee(25,"Vijay",50000);
		Employee e3=new Employee(26,"Dheeraj",40000);
		Employee e4=new Employee(22,"Suraj",50000);
		Employee e5=new Employee(24,"Ajay",30000);
		Employee e6=new Employee(25,"Rajnish",20000);
		ArrayList<Employee> al=new ArrayList<Employee>();
		al.add(e1);
		al.add(e2);
		al.add(e3);
		al.add(e4);
		al.add(e5);
		al.add(e6);
		System.out.println("before sorting:"+al);
	
		Collections.sort(al, new EmployeeComparetor());
	
		System.out.println("after sorting:"+al);
		
	}

}
