package sortingPck;

import java.util.Comparator;

public class EmployeeComparetor implements Comparator<Employee> {
	/*public int compare(Object o1,Object o2) {
		Employee e1=(Employee) o1;
		Employee e2=(Employee) o2;
		int age=Integer.compare(e1.getAge(), e2.getAge());
		if(age==0)
		{
			int nameValue=e1.getName().compareTo(e2.getName());
			if (age==0 && nameValue==0){
				long salary=Long.compare(e1.getSalary(),e2.getSalary());
				
	           return (int) salary;
			}
			else return nameValue;
		}
		else return age;
	}*/

	@Override
	public int compare(Employee e1, Employee e2) {
		
		int age=Integer.compare(e1.getAge(), e2.getAge());
		if(age==0)
		{
			int nameValue=e1.getName().compareTo(e2.getName());
			if (age==0 && nameValue==0){
				long salary=Long.compare(e1.getSalary(),e2.getSalary());
				
	           return (int) salary;
			}
			else return nameValue;
		}
		else return age;
	}	

}
