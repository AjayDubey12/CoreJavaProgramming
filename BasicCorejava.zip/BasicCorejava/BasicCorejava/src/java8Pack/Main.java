package java8Pack;

public class Main implements Interface1 {
public static void main(String args[]){
	
	
	Main t=new Main();
	t.log("default interface method");
	Interface1.log1("default interface method");
	t.method1("implemnt");
	
}

@Override
public void method1(String str) {
System.out.println("implemented method from parent ");	
}

}
