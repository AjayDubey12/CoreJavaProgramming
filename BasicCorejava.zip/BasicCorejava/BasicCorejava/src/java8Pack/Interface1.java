package java8Pack;
public interface Interface1 {

	void method1(String str);
	
	 default void log(String str){
		System.out.println("I1 logging::"+str);
	}
	public static  void log1(String str){
		System.out.println("I1 logging::"+str);
	}
}