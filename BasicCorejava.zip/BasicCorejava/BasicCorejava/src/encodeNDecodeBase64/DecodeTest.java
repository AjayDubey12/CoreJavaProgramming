package encodeNDecodeBase64;

import org.apache.commons.codec.binary.Base64;

public class DecodeTest {

	public static String decodeEncodedInput(byte[] s){
		
		
		
		
		return new String(Base64.decodeBase64(s));
		
		
		
	}

	

}
