package encodeNDecodeBase64;


import java.io.IOException;

import org.apache.commons.codec.binary.Base64;

/**
 * Java program to encode and decode String in Java using Base64 encoding algorithm
 * @author http://javarevisited.blogspot.com
 */
public class Base64EncodingExample{

    public static void main(String args[]) throws IOException {
        String password = "sathish";

        //encoding  byte array into base 64
        byte[] encoded = Base64.encodeBase64(password.getBytes());     
      
        System.out.println("Original String: " + password );
        System.out.println("Base64 Encoded String : " + new String(encoded));
      
        //decoding byte array into base64
       /* byte[] decoded = Base64.decodeBase64(encoded);      
        System.out.println("Base 64 Decoded  String : " + new String(decoded));
*/
        
     String decodedPas=   DecodeTest.decodeEncodedInput(encoded);
     System.out.println(decodedPas);
   }
}

