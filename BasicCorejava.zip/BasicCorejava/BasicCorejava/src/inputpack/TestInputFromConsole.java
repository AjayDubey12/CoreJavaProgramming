package inputpack;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class TestInputFromConsole {

	public static void main(String[] args) throws IOException {
		//3 way to read input from console
		//Bufferedreder+InputStreamReader
		//Scanner(jdk1.5)
		//System.console()(jdk 1.6)
		
		System.out.println("enter input");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
       String s=br.readLine();
       System.out.println("enter inputS");
       
       Scanner sc=new Scanner(System.in);
       String s1=sc.nextLine();
       System.out.println("enter input  from system console");
       try{
       System.console().readLine();   //3.ways This System.console() is usable only outside IDE, a bit hard for testing.
       }catch(Exception e){
    	   System.out.println("exception occur");
    	   e.printStackTrace();
    	   
       }
       
	
	
	}
	

}
