package parserPack;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class QueryXmlFileDemo {

   public static void main(String argv[]) {
 
      try {
        // File inputFile = new File("src/cars.txt");
         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         Document doc = dBuilder.parse(new File("src/cars.xml"));
         doc.getDocumentElement().normalize();
         System.out.print("Root element: ");
         System.out.println(doc.getDocumentElement().getNodeName());
         NodeList nList = doc.getElementsByTagName("supercars");
         System.out.println("----------------------------");
         
         for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :"+nNode.getNodeName());
          //  System.out.print();
            
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               Element eElement = (Element) nNode;
               System.out.print("company : "+eElement.getAttribute("company"));
               
               NodeList carNameList = eElement.getElementsByTagName("carname");
               
               
            
               
               for (int count = 0; count < carNameList.getLength(); count++) {
                  Node node1 = carNameList.item(count);
                  System.out.println();
               //   System.out.println("\nCurrent Element :" + node1.getNodeName());

                  if (node1.getNodeType() == node1.ELEMENT_NODE) {
                     Element car = (Element) node1;
                     System.out.println("car type : "+car.getAttribute("type"));
                     System.out.println("car name : "+car.getTextContent());
                    
                    
                  //   System.out.println());
                  }
               }
            } 
         }
      NodeList list2=   doc.getElementsByTagName("luxurycars");
      for(int i=0;i<list2.getLength();i++){
    Node node=	  list2.item(i);
    if(node.getNodeType()==node.ELEMENT_NODE){
    	Element e=(Element) node;
    System.out.println("company : "+e.getAttribute("company"));
    NodeList l2=	e.getElementsByTagName("carname");
    	for(int j=0;j<=l2.getLength();j++){
    		
    		Node n3=l2.item(j);
    		if(n3.getNodeType()==Node.ELEMENT_NODE){
    		Element	element3=(Element) n3;
    			System.out.println("car name is"+element3.getTextContent());
    			
    		}
    		
    		
    	}
    	 
         System.out.println("car name : "+e.getTextContent());
        
    	
    	
    }
    	  
      }
         
         
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}