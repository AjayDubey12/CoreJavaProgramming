package inheritepack;

public class Child extends Parent {
	public Child(){
		super();
		
		}
public void m1()throws Exception{
	
	System.out.println("child");
	
}
{
try{	
super.m1();
}catch(Exception e){

}
}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Parent p=new Child();
		
	p.m1();
	}

}
