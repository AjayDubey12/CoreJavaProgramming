package inheritepack;

public class Parent {
public void m1()throws Exception{
	System.out.println("parent");
	System.out.println();
	throw new RuntimeException();
	
}
}
