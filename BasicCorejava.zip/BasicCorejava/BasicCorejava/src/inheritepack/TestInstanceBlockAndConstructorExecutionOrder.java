package inheritepack;
class X{
	static int i=0;
    public X()
    {
        System.out.println("Class X Constructor");
    }
    {
    	i++;
    	System.out.println("Class x instance block");
    }
}
 
class Y extends X
{
  
{
    	
    	System.out.println("Class y instance block");
    }public Y()
    {
        System.out.println("Class Y Constructor");
    }
{
    	
    	System.out.println("Class y instance block");
    }
}
 
class Z extends Y
{
    public Z()
    {
        System.out.println("Class ZConstructor");
    }
}
 
public class TestInstanceBlockAndConstructorExecutionOrder
{
    public static void main(String[] args)
    {
    	System.out.println("static cotrol flow");
       /* Z z = new Z();
        Z z1=new Z();
        Z z2=new Z();
        System.out.println(z.i);*/
    
    }
}

