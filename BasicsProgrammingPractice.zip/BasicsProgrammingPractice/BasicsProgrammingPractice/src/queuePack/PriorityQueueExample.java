package queuePack;

import java.util.PriorityQueue;

public class PriorityQueueExample {
public static  void main(String[] args) {
PriorityQueue pq=new PriorityQueue();	
//pq.add(null);
pq.add(new Student(1,"Ajay",10,80.9));
pq.add(new Student(3,"Sathish",9,91.9));
pq.add(new Student(2,"Amrish",12,90.9));//all element should be comparableS
int count =0;
System.out.println(pq);
while(!pq.isEmpty()){
	
	System.out.println("Dequeue "+count++ +"  "+pq.remove());
	
	
}
System.out.println(pq);
}
}

