package copanyTestPack;

public interface A {

}
