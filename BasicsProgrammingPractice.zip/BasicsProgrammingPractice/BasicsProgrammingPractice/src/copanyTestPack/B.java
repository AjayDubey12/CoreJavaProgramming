package copanyTestPack;

public class B implements A {

}
