package copanyTestPack;

public class C implements A {

}
