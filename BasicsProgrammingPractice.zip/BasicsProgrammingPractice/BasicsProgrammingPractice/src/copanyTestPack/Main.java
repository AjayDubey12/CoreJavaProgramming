package copanyTestPack;

public class Main {

	public static void main(String[] args) {
	A a=new B();
		C c=new C();
		c= (C) a;//throw exception At run time  , copanyTestPack.B cannot be cast to copanyTestPack.C
	}

}
