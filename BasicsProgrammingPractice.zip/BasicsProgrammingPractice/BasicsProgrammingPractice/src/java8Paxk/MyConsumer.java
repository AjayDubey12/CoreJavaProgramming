package java8Paxk;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class MyConsumer<T> implements Consumer<T> {
	@Override
	public void accept(T t) {
		System.out.println(t);
	}

	public static void main(String[] args) {
		//creating sample Collection
				List<Integer> myList = new ArrayList<Integer>();
				for(int i=0; i<10; i++) 
				{myList.add(i);
				
				
				
				}
				
				MyConsumer action = new MyConsumer();
				myList.forEach(action);
					
	}

	
}
