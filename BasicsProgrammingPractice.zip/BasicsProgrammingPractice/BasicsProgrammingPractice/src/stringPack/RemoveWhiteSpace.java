package stringPack;

import java.util.StringTokenizer;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="welcome to learn basic string in java ";


int count=new StringTokenizer(s, " ").countTokens();


System.out.println(count);


//String str=s.replaceAll("\\s", "");
String str=s.replaceAll(" ", "");
System.out.println(str);
	}

}
