package inheritanceFlow;

public class Child extends Parent {
	private int i;
	private int j;
	public Child(){
		
		System.out.println("inside child constructor");
		
	}
	static {
		
		System.out.println("inside child static block");
		
		
	}
	{
		
		System.out.println("inside child instance  block");
		
		
	}
	public static void main(String[] args) {
		
//1.static control flow will happen
		
		
		System.out.println("");
		
		
		Child obj=new Child();
		//Parent p=new Parent();
		//instance control flow will be happen
	}

}
