package inheritanceFlow;

public class Parent {
private int i;
private int j;
public Parent(){
	
	System.out.println("inside Parent constructor");
	
}
static {
	
	System.out.println("inside parent static block");
	
}
{	
	System.out.println("inside parent instance  block");
	
}
}
