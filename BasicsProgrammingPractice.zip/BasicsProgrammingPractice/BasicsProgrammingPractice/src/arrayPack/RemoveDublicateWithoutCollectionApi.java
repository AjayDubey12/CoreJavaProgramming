package arrayPack;

import java.util.Arrays;
import java.util.List;

public class RemoveDublicateWithoutCollectionApi{
	public static int[] removeDuplicates(int[] numbersWithDuplicates) {

        // Sorting array to bring duplicates together      
        Arrays.sort(numbersWithDuplicates);     
      
        int[] result = new int[numbersWithDuplicates.length];
        int previous = numbersWithDuplicates[0];
        result[0] = previous;
int index=1;
        for (int i = 1; i < numbersWithDuplicates.length; i++) {
            int ch = numbersWithDuplicates[i];

            if (previous != ch) {
                result[index++] = ch;
            }
            previous = ch;
        }
        return result;

    }
		
public static void main(String args[]) {
	int dublicateArr[]={1, 1, 2, 2, 3, 4, 5};
	int result []=removeDuplicates(dublicateArr);
	for(int i:result) {
		
		System.out.println(i);
	}
}		
	
}
