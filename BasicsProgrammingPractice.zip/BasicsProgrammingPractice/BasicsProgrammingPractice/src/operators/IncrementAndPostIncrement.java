package operators;

public class IncrementAndPostIncrement {

	public static void main(String[] args) {
		int a=5,i;

		i=++a + ++a + a++;
		i=a++ + ++a + ++a;
		
		System.out.println(a);
		
		a=++a + ++a + a++;
		System.out.println(i);
		System.out.println(a);
		
		
	int 	j=0;
	int	k=j++ + ++j;  //k=0 (j=1)+(1+1)(j=2)=2
	System.out.println(k +" "+j);
	int a1=1;
	 
    System.out.println(a1++);//1(a1=2)
    System.out.println(a1++);//2(a1=3)
    System.out.println(++a1);//4
 
    System.out.println(a1++);//4(a1=5)
    System.out.println(a1++);//5(a1=6)
 
    System.out.println(a1--);//6(a1=5)
    System.out.println(a1--);//5(a1=4)
    System.out.println(a1);
 
    System.out.println(--a1);//3(a1=3)
    System.out.println(--a1);//2(a1=2)
    System.out.println(a1--);//2(a1=1)
 
	
	}

}
