package operators;

public class Test {

	public static void main(String[] args) {

int v=3 ;
int sum=6+--v;
int j=2%8;
int k=2/8;

int d=--v + ++v/sum++ *v++ + ++sum%v--;
System.out.println(d+" expression "+ ++v/sum++ *v++  +" "+ ++sum%v--);


System.out.println("j    "+j + "  "+ k);
	}

}
