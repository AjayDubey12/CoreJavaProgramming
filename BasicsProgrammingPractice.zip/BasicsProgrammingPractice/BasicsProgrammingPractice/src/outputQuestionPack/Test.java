package outputQuestionPack;
class Test {
	public static void main(String[] args) {
		for(int i = 0; 1; i++) {
			System.out.println("Hello");
			break;
		}
	}
}
