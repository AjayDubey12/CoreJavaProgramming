package filePack;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class TextFileInfoPrinter
{  
    public static void main(String[]args) throws IOException        
    { //
         
            System.out.println("File to be read: ");
                     FileReader file = new FileReader("d:\\ajay.txt");
            Scanner in = new Scanner(file);
   BufferedReader br=new BufferedReader(file);

            int words = 0;
            int lines = 0;
            int chars = 0;

           /* while(in.hasNext())
            {
                in.next();
                words++;
            }

            while(in.hasNextLine())
            {
                in.nextLine();
                lines++;
            }

            while(in.hasNextByte())
            {
                in.nextByte();
                chars++;
            }
*/
          /*  while(in.hasNextLine())  {
               
                String line = in.nextLine();
                chars += line.length();
                words += new StringTokenizer(line, " ,").countTokens();
                lines++;
                		
            }*/
            String line=null;
            while((line=br.readLine())!=null){
           String[] split= 	line.split(" ");
           words=words+split.length;
            	
            }
            System.out.println("Number of lines: " + lines);
            System.out.println("Number of words: " + words);
            System.out.println("Number of characters: " + chars);
    }
}