package filePack;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderClass {

	public static void main(String[] args) throws IOException {
		FileReader reader=null;
		BufferedReader br=null;
	 try {
		reader=new FileReader("C:\\Users\\E6420\\Desktop\\StringConstantPoolTheory.txt");
		
		br=new BufferedReader(reader);
		String sCurrentLine;
		int count=0;

		while ((sCurrentLine = br.readLine()) != null) {
			
		       count++;
		   	System.out.println(count);
			System.out.println(sCurrentLine);
		
		}
		System.out.println(count);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
finally{
	if(br!=null){
		
		br.close();
	}
	if(reader!=null){
		
		reader.close();
	}
	
}
	}

}
