package filePack;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriteToFileExample {

	public static void main(String[] args) {
		FileWriter fw=null;
		BufferedWriter  bw=null;
		
		try {

			String content = "This is the content to write into file\n";

			fw = new FileWriter("D:\\ajay.txt");
			bw = new BufferedWriter(fw);
			bw.write(content);

			System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
	}

}
