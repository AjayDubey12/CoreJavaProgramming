
public class Y extends X {

		
		static{
			 i=i-- - --i;//-2(-3)-(-4)=2
			
		}
		{
	 i=i++ - ++i;	//2(3)-4(4)=-2


		}
	public static void main(String[] args) {
		Y y=new Y();
System.out.println(y.i);
	}

}
