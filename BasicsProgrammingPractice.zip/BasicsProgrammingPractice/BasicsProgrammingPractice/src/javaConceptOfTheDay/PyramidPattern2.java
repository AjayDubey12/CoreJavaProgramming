package javaConceptOfTheDay;

import java.util.Scanner;

public class PyramidPattern2 {
public static void main(String args[]){
	System.out.println("enter total no of rows ");
	Scanner sc=new Scanner(System.in);
	int noOfRows=sc.nextInt();
	int rowCount=1;
	for(int i=noOfRows;i>0;i--){
		
		for(int j=1;j<i;j++){
			
			System.out.print(" ");
			
		}
		for(int j=1;j<=rowCount;j++){
			
			System.out.print(j+" ");
			
		
		}
		System.out.println();
		rowCount++;
		
	}
	
}
}
