package javaConceptOfTheDay;

import java.util.Scanner;

public class PyramidTestPractice {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Inter no of row ");
		int noOfRow=sc.nextInt();
		int rowCount=1;
		for(int i=noOfRow;i>0;i--)
		{
		for (int j=1;j<i;j++){
			
			System.out.print(" ");
			
		}	
		for(int j=1;j<rowCount;j++){
			
			System.out.print("*"+" ");
			}
		System.out.println();
		rowCount++;
		}
	}

}
