package javaConceptOfTheDay;
public class ArraysInJava
{
    public static void main(String[] args)
    {
        int[] i = new int[-5];   //No Compile Time Error
 
        //You will get java.lang.NegativeArraySizeException at run time
    }
}
