package javaConceptOfTheDay;

import java.io.IOException;

public class LaunchingExternalApps
{
    public static void main(String[] args) throws InterruptedException
    {
        Runtime runtime = Runtime.getRuntime();     //getting Runtime object
 
        String[] s = new String[] {"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe", "http://javaconceptoftheday.com/"};
        Process process;
        try
        {
         process=  runtime.exec(s); //opens "http://javaconceptoftheday.com/" in chrome browser
        
         Thread.sleep(5000);
         
         process.destroy();//and close after 5 second
         
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
       
    }
}