package javaConceptOfTheDay;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MostFrequestElementProgram {
	public static void mostFrequenTelement(int inputArray[]) {
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		for (int i : inputArray) {
			if (hm.containsKey(i)) {

				hm.put(i, hm.get(i) + 1);
			} else {

				hm.put(i, 1);
			}
		}
		int element = 0;
		int frequency = 1;
		Set<Entry<Integer, Integer>> s = hm.entrySet();
		for (Entry<Integer, Integer> entry : s) {

		if (entry.getValue() > frequency) {

				frequency = entry.getValue();
				element = entry.getKey();
			}

		}
		if(frequency>1){
			System.out.println("Input Array : "+Arrays.toString(inputArray));
			System.out.println("most frequent elemet is"+"  "+element);
			System.out.println("frequency of element is"+"  "+frequency);
			
			
		}else {
			
			
			System.out.println("all element are unique");
		}

	}

	public static void main(String args[]) {

		int a[] = { 3, 4, 3, 5, 6, 7, 2, 7, 8, 7,3,3 };

		mostFrequenTelement(a);

	}
}
