package javaConceptOfTheDay;

import java.util.Scanner;

public class RemoveVawelFromString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter input string");
		String str = sc.nextLine();
		
		/*
		 * String s1= s.replaceAll("[AEIOUaeiou]", ""); 
		 * System.out.println(s1);
		 */

		System.out.print("Removing Vowels from String [" + str + "]\n");
		
	String 	r = removeVowels(str);

		System.out.print("Vowels Removed from the Entered String Successfully..!!\nNow the String is :\n");
		System.out.print(r);
	}

	private static String removeVowels(String s) {
		String finalString = "";
		

		for (int i = 0; i < s.length(); i++) {
			if (!isVowel(Character.toLowerCase(s.charAt(i)))) {
				finalString = finalString + s.charAt(i);
			}
		}
		return finalString;
	}

	private static boolean isVowel(char c) {

		/*String vawels = "aeiou";

		for (int i = 0; i < 5; i++)
			if (c == vawels.charAt(i)) {
				return true;
			}
		return false;

	}

}*/
		  switch(c){
          case 'A': case 'E': case 'I': case 'O': case 'U':
          case 'a': case 'e': case 'i': case 'o': case 'u':
              return true;
          default:
              return false;           
        }
    }
}