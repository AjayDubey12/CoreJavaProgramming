package javaConceptOfTheDay;

public class AssignArrayReferenceToAnother
{
    public static void main(String[] args)
    {
        int[] a = new int[10];
 
        int[] b = new int[100];
 
        double[] c = new double[20];
 
        a = b;//While assigning one array reference variable to another, 
               // compiler checks only type of the array not the size
 
        b = c;     //Compile Time Error : can not convert from double[] to int[]
    }
}
