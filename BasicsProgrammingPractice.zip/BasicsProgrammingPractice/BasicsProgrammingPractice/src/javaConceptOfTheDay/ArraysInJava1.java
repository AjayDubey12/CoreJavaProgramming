package javaConceptOfTheDay;

	public class ArraysInJava1
{
    public static void main(String[] args)
    {
        Object[] o = new String[10];    //No Compile Time Error : String[] is auto-upcasted to Object[]
 
        //i.e array object of strings can be referred by array reference variable of Object type
 
        o[2] = "java";
 
        o[5] = 20;   //No Compile time error, //but you will get java.lang.ArrayStoreException at run time.
 
        
    }
}
