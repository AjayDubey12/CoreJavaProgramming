package javaConceptOfTheDay;

public class AnnonymousArraysInJava
{
    public static void main(String[] args)
    {
        //Creating anonymous array
 
        System.out.println(new int[]{1, 2, 3}.length);    //Output : 3
 
        System.out.println(new int[]{47, 21, 58, 98}[1]);   //Output : 21
    }
}