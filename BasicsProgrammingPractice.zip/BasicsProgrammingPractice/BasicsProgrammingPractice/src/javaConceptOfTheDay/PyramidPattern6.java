package javaConceptOfTheDay;

import java.util.Scanner;

public class PyramidPattern6 {
	public static void main(String args[]) {
		System.out.println("enter total no of rows ");
		Scanner sc = new Scanner(System.in);
		int noOfRows = sc.nextInt();
		int rowCount = 1;
		for (int i = noOfRows; i > 0; i--) {

			for (int j = 1; j < 2 * i; j++) {

				System.out.print(" ");

			}
			for (int j = i; j <= noOfRows; j++) {

				System.out.print(j + " ");
			}
			for (int j = noOfRows - 1; j >= i; j--) {

				System.out.print(j + " ");
			}
			System.out.println();
			rowCount++;

		}

	}
}
