package javaConceptOfTheDay;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class SecondlargestElement {

	public static void main(String[] args) {
		int[] arr = new int[] { 23, 4, 20, 50, 30, 10, 60, 40, 70, 75, 100 ,80,80};
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		
		
		int firstLargest = arr[0];
		int secondlargest = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > firstLargest) {
				secondlargest = firstLargest;
				firstLargest = arr[i];
			} else if (arr[i] > secondlargest) {

				secondlargest = arr[i];

			}

		}
		System.out.println("second largest no is" + "  " + secondlargest);
		System.out.println("First largest no is" + "  " + firstLargest);
	}

}
