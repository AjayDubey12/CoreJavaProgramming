
public class X {
	 public static int i=1111;
static{
	i=i-- - --i;//1111(i=1110)-1109(i=1109)==2
	
}
{
i=i++-++i;	//2(i=3)-4(i=4)=-2


}

	
	
}

